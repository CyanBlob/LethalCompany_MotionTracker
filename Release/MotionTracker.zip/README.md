## Motion Tracker [BETA]
Can be bought in the terminal to track movement near the player

**Version 0.1.3**
- Update for game v45
- Potentially fix audio bug causing audio to be heard from object's perspective instead of player's

**Version 0.1.3**
 - Fix bug causing players to enter a glitched state when dropping the Motion Tracker in multiplayer
 
**Version 0.1.2**
- Increased duration to 60 seconds (up from 45)
