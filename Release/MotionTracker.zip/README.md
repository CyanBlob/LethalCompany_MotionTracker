[BETA]
Can be bought in the terminal to track movement near the player